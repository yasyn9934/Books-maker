# عقد الغلاف الأصلي (Kotlin) مع واجهة الويب — للمرحلة ب

الغلاف مسؤول عن: شاشة الترحيب/التحميل، شاشة الأخطاء، تخزين ملفات الموقع محلياً وتقديمها، التحقق من التوقيع، الإشعارات.
واجهة الويب (`app.html` وما حولها) تتحدّث معه عبر الجسر التالي.

## التعريف
- أضف لوكيل المستخدم: `RoyalBooksApp/<versionName>`.
- `addJavascriptInterface(obj, "RoyalNative")` بالدوال:
  | الدالة | الوظيفة |
  |---|---|
  | `notify(title, body)` | إشعار نظام (بعد إذن POST_NOTIFICATIONS) |
  | `requestNotificationPermission()` | يطلب إذن الإشعارات |
  | `openExternal(url)` | يفتح رابط http/https في المتصفح الخارجي |
  | `saveFile(name, mime, base64)` | يحفظ ملفاً مُصدَّراً في التنزيلات (يُستدعى من DownloadListener) |
  | `getInstalled()` / `getAppVersion()` | نسخة الملفات المثبَّتة / نسخة التطبيق |
  | `downloadUpdate(json)` | يحمّل `build` المطلوب، **يتحقق بنفسه** من التوقيع والبصمات، ثم يستبدل الملفات ذرّياً |
- النتائج تُرسل بـ `webView.evaluateJavascript("window.onRoyalNative(" + json + ")")`:
  `{type:'progress',done,total}` · `{type:'done',version,build}` · `{type:'error',message}`

## التحقق (إلزامي في الغلاف، لا تعتمد على JS)
`version.json = { payload: "<نص JSON>", signature: "<base64>" }`
- التوقيع ECDSA P-256 + SHA-256 على بايتات `payload` (UTF-8) بصيغة r‖s (64 بايت). المفتاح العام SPKI/base64 مضمَّن في الغلاف نفسه.
- بعد التحقق: لكل ملف في `payload.files` حمّل `SITE_BASE + path`، وقارن SHA-256 بـ `sha256`. ارفض أي `path` فيه `..` أو يبدأ بـ `/`.
- حمّل في مجلد مؤقت، وإذا نجح كل شيء بدّل المجلد الحالي به. إن فشل أبقِ القديم.

## التقديم
قدّم الملفات من التخزين الداخلي عبر `WebViewAssetLoader` على `https://appassets.androidplatform.net/` وابدأ من `app.html`.
يُشغَّل التطبيق **دائماً من الملفات المحلية**؛ الإنترنت للمزامنة مع درايف وفحص `version.json` فقط.

## أخرى
- `webView.settings.mediaPlaybackRequiresUserGesture = false` (صوت التنبيه).
- زر الرجوع: استدعِ `window.RoyalAppBack()`؛ إن رجع `true` فقد عالجه، وإلا أغلق التطبيق.

## ملاحظات إضافية (الإصدار 1.1)
- نوافذ `alert/confirm/prompt` تُعرض بـ AlertDialog أصلي (بدونها تُرجع confirm() القيمة false في WebView).
- أي انتقال للصفحة الرئيسية في الـ WebView إلى غير `app.html` يُمنع ويُمرَّر إلى `RoyalApp.route(...)` فتُفتح الصفحة في تبويبها.
