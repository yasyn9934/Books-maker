// يبني version.json موقَّعاً.  الاستعمال:
//   node tools/make-release.mjs --version 1.1.0 --type minor --title "عنوان" --summary "موجز" \
//        --description "وصف" --change "تغيير 1" --change "تغيير 2"
// type: major | minor | patch | hotfix      (build يزيد تلقائياً عن الإصدار السابق)
import { readFileSync, writeFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { createHash, sign, createPrivateKey } from 'node:crypto';
import { join, relative, sep } from 'node:path';
const root = new URL('..', import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, '$1');
const a = process.argv.slice(2), opt = { change: [] };
for (let i = 0; i < a.length; i++) if (a[i].startsWith('--') && a[i] !== '--unsigned') { const k = a[i].slice(2), v = a[++i]; k === 'change' ? opt.change.push(v) : (opt[k] = v); }
if (!opt.version || !opt.type) { console.error('مطلوب: --version و --type'); process.exit(1); }
if (!['major', 'minor', 'patch', 'hotfix'].includes(opt.type)) { console.error('type غير صالح'); process.exit(1); }
const unsigned = process.argv.includes('--unsigned');   // للتجربة فقط: بلا توقيع (يقبله التطبيق إن كان المفتاح العام فارغاً)
const keyFile = join(root, 'tools', 'release-private.pem');
if (!unsigned && !existsSync(keyFile)) { console.error('لا يوجد مفتاح خاص. شغّل أولاً: node tools/gen-keys.mjs'); process.exit(1); }

const EXCLUDE_DIRS = new Set(['.git', '.github', 'tools', 'docs', 'node_modules', 'android']);
const EXCLUDE_FILES = new Set(['version.json', '.gitignore', 'README.md', 'CNAME']);
const EXT = /\.(html|js|css|json|png|jpe?g|webp|svg|ico|ttf|woff2?)$/i;
const files = [];
(function walk(d) {
  for (const n of readdirSync(d)) {
    const p = join(d, n), st = statSync(p);
    if (st.isDirectory()) { if (!EXCLUDE_DIRS.has(n)) walk(p); continue; }
    if (EXCLUDE_FILES.has(n) || !EXT.test(n)) continue;
    const buf = readFileSync(p);
    files.push({ path: relative(root, p).split(sep).join('/'), sha256: createHash('sha256').update(buf).digest('hex'), size: buf.length });
  }
})(root);
files.sort((x, y) => x.path.localeCompare(y.path));

let prevBuild = 0;
try { prevBuild = JSON.parse(JSON.parse(readFileSync(join(root, 'version.json'), 'utf8')).payload).build || 0; } catch (e) {}
const release = {
  schema: 1, version: opt.version, build: prevBuild + 1, type: opt.type, date: opt.date || new Date().toISOString().slice(0, 10),
  title: opt.title || '', summary: opt.summary || '', description: opt.description || '', changes: opt.change, files
};
const payload = JSON.stringify(release);
const signature = unsigned ? '' : sign('sha256', Buffer.from(payload, 'utf8'), { key: createPrivateKey(readFileSync(keyFile)), dsaEncoding: 'ieee-p1363' }).toString('base64');
writeFileSync(join(root, 'version.json'), JSON.stringify({ payload, signature }, null, 2));
console.log(`✔ version.json: v${release.version} (build ${release.build}) — ${files.length} ملفاً`);
