// يولّد زوج مفاتيح التوقيع (ECDSA P-256) مرة واحدة.  الاستعمال:  node tools/gen-keys.mjs
// - المفتاح الخاص يُحفظ في tools/release-private.pem (لا ترفعه إلى GitHub أبداً! مُدرَج في .gitignore)
// - المفتاح العام يُكتب تلقائياً في app-config.js (UPDATE_PUBKEY)
import { generateKeyPairSync } from 'node:crypto';
import { writeFileSync, readFileSync, existsSync } from 'node:fs';
const pem = new URL('./release-private.pem', import.meta.url);
if (existsSync(pem) && !process.argv.includes('--force')) { console.error('المفتاح موجود مسبقاً. استعمل --force لاستبداله (سيبطل كل الإصدارات السابقة المثبَّتة!).'); process.exit(1); }
const { publicKey, privateKey } = generateKeyPairSync('ec', { namedCurve: 'P-256' });
writeFileSync(pem, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
const pub = publicKey.export({ type: 'spki', format: 'der' }).toString('base64');
const cfgUrl = new URL('../app-config.js', import.meta.url);
let cfg = readFileSync(cfgUrl, 'utf8');
cfg = cfg.replace(/UPDATE_PUBKEY:\s*'[^']*'/, `UPDATE_PUBKEY: '${pub}'`);
writeFileSync(cfgUrl, cfg);
console.log('\nضع هذا السطر في gradle.properties داخل مشروع الأندرويد:\nupdatePubKey=' + pub + '\n');
console.log('✔ تم توليد المفاتيح.\n  الخاص: tools/release-private.pem  (احتفظ بنسخة احتياطية آمنة خارج المستودع)\n  العام: كُتب في app-config.js — ارفع app-config.js إلى المستودع.');
